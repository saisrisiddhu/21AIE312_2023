# necessary packages
import streamlit as st
from PIL import Image
import numpy as np
import tensorflow as tf

# Load your pretrained model
@st.cache(allow_output_mutation=True)
def load_model():
    model = tf.keras.models.load_model('model.h5')
    return model

def main():
    st.title("Image Processing with Pre-trained Model")
    model = load_model()

    file = st.file_uploader("Please upload an image file", type=["jpg", "png"])
    
    if file is not None:
        image = Image.open(file)
        st.image(image, use_column_width=True)
        processed_image = preprocess(image)
        
        st.write("Processing the image with the model...")
        prediction = model.predict(np.array([processed_image]))

        st.write("Displaying the processed image")
        st.image(prediction[0], use_column_width=True)

def preprocess(img):
    # Preprocessing function to convert image into the format your model expects
    # This would depend on your model's input shape and any pre-processing steps it performs
    # Here, we're resizing to (224, 224) and normalizing pixel values to be between 0 and 1
    img = img.resize((28, 28))
    img = np.array(img)
    img = img / 255.0
    return img

if __name__ == "__main__":
    main()
