import streamlit as st
import numpy as np
from keras.preprocessing.image import ImageDataGenerator
import matplotlib.pyplot as plt
import tensorflow as tf
import os
import tempfile
from tensorflow import keras
from keras.utils import img_to_array,load_img
import warnings
warnings.filterwarnings("ignore")
from tensorflow.keras.models import Model
from tensorflow.keras.applications.resnet50 import preprocess_input

import cv2

import base64
def add_bg_from_local(image_file):
    with open(image_file, "rb") as image_file:
        encoded_string = base64.b64encode(image_file.read())
    st.markdown(
    f"""
    <style>
    .stApp {{
        background-image: url(data:image/{"png"};base64,{encoded_string.decode()});
        background-size: cover
    }}
    </style>
    """,
    unsafe_allow_html=True
    )
add_bg_from_local('background.jpg')    

training_dataset = ImageDataGenerator()
training_dataset = training_dataset.flow_from_directory('char_balanced/train', target_size=(128, 128))
class_labels = training_dataset.class_indices
class_labels = {v: k for k, v in class_labels.items()}

st.markdown("<b><h1 style='text-align:center; color:black;'>Broken Character Recognition</h1></b>", unsafe_allow_html=True)
st.markdown("<b style='color:black;'>Upload an image</b>",unsafe_allow_html=True)
file_upload = st.file_uploader("Select the image from your computer:", type=["png", "jpg", "jpeg"])

if (file_upload == None):
    st.write("Please upload the image...")
else:
    temp_dir = tempfile.mkdtemp()
    temp_file_path = os.path.join(temp_dir,file_upload.name)
    with open(temp_file_path,'wb') as temp_file:
        temp_file.write(file_upload.read())
    
    image = cv2.imread(temp_file_path)
    _, binary_image = cv2.threshold(image, 0, 255, cv2.THRESH_BINARY)

    # binary_image = cv2.bitwise_not(binary_image)
    st.write("Binary Image")
    st.image(binary_image)
    model = tf.keras.models.load_model("customcnn_alpha.h5")
    
    def predict_image(image_path):
        img = cv2.resize(image_path,(128,128))
        img_array = img_to_array(img)
        img_array = np.expand_dims(img_array, axis=0)
        img_array = preprocess_input(img_array)

        prediction = model.predict(img_array)
        predicted_label = class_labels[np.argmax(prediction)]

        return predicted_label
    
    predicted_label = predict_image(binary_image)

    st.write("The Predicted Label")
    st.write(predicted_label)

    # Show label image
    label_image_path = os.path.join("label_images", f"{predicted_label}.png")
    label_image = cv2.imread(label_image_path)
    st.image(label_image, use_column_width=True)
