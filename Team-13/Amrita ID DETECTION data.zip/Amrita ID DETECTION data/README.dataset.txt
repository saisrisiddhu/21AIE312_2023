# Amrita ID CARD detection and recogniton > 2023-05-10 9:46pm
https://universe.roboflow.com/dl-project-annotations/amrita-id-card-detection-and-recogniton

Provided by a Roboflow user
License: CC BY 4.0

